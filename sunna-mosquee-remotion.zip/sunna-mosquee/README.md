# Sunna de la mosquée : motion design Remotion (9:16)

## Installation
    npm install
    npm start              # aperçu dans Remotion Studio

## Rendu MP4 (1080 x 1920, 30 fps, 60 s)
    npm run render         # produit out/motion_design_sunna_mosquee.mp4

## Narration (à ajouter avant le rendu)
Déposer dans public/audio/ :
- narration-01.mp3 : « LES SUNNA DE LA MOSQUÉE » (intro)
- narration-02.mp3 : « Avant d'entrer dans la mosquée, le musulman veille à être propre... »
- narration-03.mp3 : « En entrant dans la mosquée, on peut dire : Ô Allah, ouvre-moi les portes de Ta miséricorde. »
- narration-04.mp3 : « Une fois entré, s'il n'y a pas de prière obligatoire... Tahiyyat al-Masjid... »
- narration-05.mp3 : « Dans la mosquée, il faut préserver la propreté... »
- narration-06.mp3 : « La Sunna nous enseigne à respecter la mosquée... »
Timeline (30 fps, 1080×1920) : S1 210 f (0:00-0:07), S2 300 f (0:07-0:17), S3 300 f (0:17-0:27), S4 360 f (0:27-0:39), S5 360 f (0:39-0:51), S6 270 f (0:51-1:00). Total : 1800 f = 60 s. Si tu changes un fichier audio, garde sa durée sous celle de sa scène.

## Sources religieuses (vérifiées)
- Invocation à l'entrée « اللهم افتح لي أبواب رحمتك » : Sahih Muslim, livre de la prière des voyageurs, « باب ما يقول إذا دخل المسجد », hadith 713 (rapporté par Abu Humayd ou Abu Usayd). Texte vérifié.
- Deux rak'ahs avant de s'asseoir (Tahiyyat al-Masjid) : Sahih al-Bukhari 444 et Sahih Muslim 714 (rapporté par Abu Qatada). Ibn Hajar et les imams de fatwa considèrent l'ordre comme une recommandation (mustahabb), pas une obligation : c'est formulé ainsi dans la narration 4.
- Le pied droit : AUCUNE source vérifiée. Il a été retiré de la narration 3 et n'est pas présenté comme pratique rapportée. Ne pas le réintroduire sans référence.
- Propreté, vêtements convenables, calme, discrétion : bonnes manières générales, non attribuées au Prophète ﷺ.
- À faire relire par un savant avant publication.


## Polices
Cairo (texte et titres) et Amiri (arabe) via @remotion/google-fonts (connexion internet requise au rendu).
