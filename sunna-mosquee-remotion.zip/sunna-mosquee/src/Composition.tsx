import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Scene01Intro} from './scenes/Scene01Intro';
import {Scene02Preparation} from './scenes/Scene02Preparation';
import {Scene03Entree} from './scenes/Scene03Entree';
import {Scene04Priere} from './scenes/Scene04Priere';
import {Scene05Respect} from './scenes/Scene05Respect';
import {Scene06Conclusion} from './scenes/Scene06Conclusion';
import {C} from './styles/colors';

// Timeline 60 s @ 30 fps = 1800 frames. Chaque scène a sa propre durée et sa propre narration.
export const SCENES = [
  {from: 0, duration: 210, audio: 'audio/narration-01.mp3', Comp: Scene01Intro},
  {from: 210, duration: 300, audio: 'audio/narration-02.mp3', Comp: Scene02Preparation},
  {from: 510, duration: 300, audio: 'audio/narration-03.mp3', Comp: Scene03Entree},
  {from: 810, duration: 360, audio: 'audio/narration-04.mp3', Comp: Scene04Priere},
  {from: 1170, duration: 360, audio: 'audio/narration-05.mp3', Comp: Scene05Respect},
  {from: 1530, duration: 270, audio: 'audio/narration-06.mp3', Comp: Scene06Conclusion},
] as const;

export const SunnaMosquee: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.beige}}>
    {SCENES.map((s) => (
      <Sequence key={s.from} from={s.from} durationInFrames={s.duration}>
        <s.Comp />
        {/* Narration : déposer les fichiers dans public/audio/ (voir README) */}
        <Audio src={staticFile(s.audio)} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
