import {loadFont as loadCairo} from '@remotion/google-fonts/Cairo';
import {loadFont as loadAmiri} from '@remotion/google-fonts/Amiri';

// Cairo: sans-serif, couvre le français et l'arabe (titres en 800, textes en 300)
const cairo = loadCairo();
// Amiri: police arabe classique, connectée correctement
const amiri = loadAmiri();

export const FONT = {
  title: `${cairo.fontFamily}, sans-serif`,
  body: `${cairo.fontFamily}, sans-serif`,
  arabic: `${amiri.fontFamily}, 'Noto Naskh Arabic', serif`,
};
