export const C = {
  beige: '#F5F0E6',
  offWhite: '#FFFDF7',
  olive: '#647653',
  darkGreen: '#263D32',
  gold: '#C5A15B',
  ink: '#242424',
};
