import React from 'react';
import {C} from '../styles/colors';

// Fond beige avec dégradé doux et sol olive.
export const Background: React.FC<{variant?: 'beige' | 'dark'}> = ({variant = 'beige'}) => (
  <div style={{position: 'absolute', inset: 0, background: variant === 'beige'
    ? `linear-gradient(180deg, ${C.offWhite} 0%, ${C.beige} 70%)`
    : `radial-gradient(circle at 50% 40%, ${C.darkGreen} 0%, #1b2b23 100%)`}}>
    <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: 260, background: C.olive, opacity: variant === 'beige' ? 0.25 : 0.4}} />
  </div>
);
