import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from '../styles/colors';

// Icônes SVG animées avec effet Pop (spring). Le paramètre `delay` cale l'apparition sur la narration.
export type IconKind = 'clothes' | 'shoes' | 'quiet' | 'mat' | 'space' | 'heart';
type Props = {kind: IconKind; x: number; y: number; delay?: number; size?: number};

const Glyph: React.FC<{kind: IconKind}> = ({kind}) => {
  switch (kind) {
    case 'clothes':
      return <path d="M-30 -30 L-12 -40 L0 -28 L12 -40 L30 -30 L22 30 L-22 30 Z" fill={C.olive} stroke={C.ink} strokeWidth={3} />;
    case 'shoes':
      return (
        <g>
          <ellipse cx={-14} cy={10} rx={16} ry={9} fill={C.darkGreen} />
          <ellipse cx={16} cy={10} rx={16} ry={9} fill={C.darkGreen} />
        </g>
      );
    case 'quiet':
      return (
        <g>
          <circle cx={0} cy={0} r={28} fill={C.offWhite} stroke={C.ink} strokeWidth={3} />
          <line x1={-12} y1={0} x2={12} y2={0} stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
        </g>
      );
    case 'mat':
      return <rect x={-34} y={-14} width={68} height={28} rx={4} fill={C.gold} stroke={C.ink} strokeWidth={3} />;
    case 'space':
      return (
        <g>
          <line x1={-30} y1={0} x2={30} y2={0} stroke={C.olive} strokeWidth={6} strokeLinecap="round" />
          <line x1={-30} y1={-14} x2={-30} y2={14} stroke={C.olive} strokeWidth={4} />
          <line x1={30} y1={-14} x2={30} y2={14} stroke={C.olive} strokeWidth={4} />
        </g>
      );
    case 'heart':
      return <path d="M0 14 C-30 -6 -18 -30 0 -16 C18 -30 30 -6 0 14 Z" fill={C.gold} stroke={C.ink} strokeWidth={3} />;
  }
};

export const AnimatedIcon: React.FC<Props> = ({kind, x, y, delay = 0, size = 1}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 14, stiffness: 120}});
  return (
    <g transform={`translate(${x} ${y}) scale(${s * size})`} opacity={Math.min(1, s * 1.5)}>
      <Glyph kind={kind} />
    </g>
  );
};
