import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../styles/colors';

// Stickman articulé : épaule, coude, poignet, hanche, genou, cheville.
// Même gabarit dans toutes les scènes, pour une apparence identique.
type Props = {x: number; y: number; scale?: number; walking?: boolean; bowing?: boolean; flip?: boolean};

const UPPER = 22;
const FORE = 20;
const THIGH = 30;
const SHIN = 30;

// Cinématique directe à deux segments. Angles en degrés, 0 = vers le bas.
const chain = (ox: number, oy: number, a1: number, a2: number, l1: number, l2: number) => {
  const r = (d: number) => (d * Math.PI) / 180;
  const jx = ox + l1 * Math.sin(r(a1));
  const jy = oy + l1 * Math.cos(r(a1));
  const ex = jx + l2 * Math.sin(r(a1 + a2));
  const ey = jy + l2 * Math.cos(r(a1 + a2));
  return {jx, jy, ex, ey};
};

const seg = (x1: number, y1: number, x2: number, y2: number) => (
  <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.ink} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
);

export const Stickman: React.FC<Props> = ({x, y, scale = 1, walking = false, bowing = false, flip = false}) => {
  const f = useCurrentFrame();
  const t = walking ? Math.sin(f * 0.22) : 0; // cycle de marche
  const headTilt = Math.sin(f * 0.05) * 3; // rotation légère de la tête
  const bow = bowing ? Math.min(1, f / 30) * 18 : 0;
  const shoulderY = -58;

  // bras opposés à la jambe, épaule -> coude -> poignet
  const armL = chain(-16, shoulderY, 10 + t * 25, -20 + t * 10, UPPER, FORE);
  const armR = chain(16, shoulderY, 10 - t * 25, -20 - t * 10, UPPER, FORE);
  // jambes, hanche -> genou -> cheville
  const legL = chain(-10, 0, t * 22, Math.max(0, -t) * 30, THIGH, SHIN);
  const legR = chain(10, 0, -t * 22, Math.max(0, t) * 30, THIGH, SHIN);

  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      <g transform={`rotate(${bow} 0 -20)`}>
        <path d="M-22 -62 L22 -62 L30 0 L-30 0 Z" fill={C.olive} stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
        <g transform={`rotate(${headTilt} 0 -70)`}>
          <circle cx={0} cy={-88} r={18} fill={C.offWhite} stroke={C.ink} strokeWidth={4} />
        </g>
        {seg(-16, shoulderY, armL.jx, armL.jy)}
        {seg(armL.jx, armL.jy, armL.ex, armL.ey)}
        {seg(16, shoulderY, armR.jx, armR.jy)}
        {seg(armR.jx, armR.jy, armR.ex, armR.ey)}
        {seg(-10, 0, legL.jx, legL.jy)}
        {seg(legL.jx, legL.jy, legL.ex, legL.ey)}
        {seg(10, 0, legR.jx, legR.jy)}
        {seg(legR.jx, legR.jy, legR.ex, legR.ey)}
      </g>
    </g>
  );
};
