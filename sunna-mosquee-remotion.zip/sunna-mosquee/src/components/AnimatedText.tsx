import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT} from '../styles/typography';
import {C} from '../styles/colors';

// Texte qui monte et apparaît (kinetic typography douce). Arabe : police Amiri.
type Props = {children: React.ReactNode; delay?: number; size?: number; weight?: number; arabic?: boolean; color?: string; style?: React.CSSProperties};

export const AnimatedText: React.FC<Props> = ({children, delay = 0, size = 64, weight = 300, arabic = false, color = C.ink, style}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 200}});
  return (
    <div
      style={{
        fontFamily: arabic ? FONT.arabic : FONT.body,
        fontSize: size,
        fontWeight: arabic ? 400 : weight,
        color,
        direction: arabic ? 'rtl' : 'ltr',
        textAlign: 'center',
        opacity: s,
        transform: `translateY(${interpolate(s, [0, 1], [30, 0])}px)`,
        lineHeight: 1.35,
        padding: '0 60px',
        ...style,
      }}
    >
      {children}
    </div>
  );
};
