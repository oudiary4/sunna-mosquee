import React from 'react';
import {interpolate, useCurrentFrame, Easing} from 'remotion';
import {C} from '../styles/colors';

// Mosquée tracée progressivement (stroke-dashoffset) puis remplie.
type Props = {x: number; y: number; scale?: number; drawFrom?: number; drawFrames?: number};

export const Mosque: React.FC<Props> = ({x, y, scale = 1, drawFrom = 0, drawFrames = 60}) => {
  const f = useCurrentFrame();
  const draw = interpolate(f - drawFrom, [0, drawFrames], [1, 0], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic),
  });
  const fill = interpolate(f - drawFrom, [drawFrames * 0.7, drawFrames], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const outline = 'M-170 0 L-170 -120 L170 -120 L170 0 Z M-60 0 L-60 -60 Q0 -110 60 -60 L60 0 Z';
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      {/* dôme */}
      <path d="M-90 -140 Q0 -260 90 -140 Z" fill={C.gold} fillOpacity={fill} stroke={C.darkGreen} strokeWidth={4}
        strokeDasharray={600} strokeDashoffset={draw * 600} />
      {/* minarets */}
      <rect x={-200} y={-240} width={28} height={240} fill={C.beige} fillOpacity={fill} stroke={C.darkGreen} strokeWidth={4}
        strokeDasharray={800} strokeDashoffset={draw * 800} />
      <rect x={172} y={-240} width={28} height={240} fill={C.beige} fillOpacity={fill} stroke={C.darkGreen} strokeWidth={4}
        strokeDasharray={800} strokeDashoffset={draw * 800} />
      {/* façade et porte */}
      <path d={outline} fill={C.offWhite} fillOpacity={fill} stroke={C.darkGreen} strokeWidth={4}
        strokeDasharray={1200} strokeDashoffset={draw * 1200} />
      {/* colonnes décoratives */}
      {[-120, -90, 90, 120].map((cx) => (
        <line key={cx} x1={cx} y1={-120} x2={cx} y2={0} stroke={C.gold} strokeWidth={5} strokeOpacity={fill} />
      ))}
    </g>
  );
};
