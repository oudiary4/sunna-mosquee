import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';

// Fondu d'entrée / sortie entre scènes (opacité + léger scale).
export const SceneFade: React.FC<{durationInFrames: number; children: React.ReactNode}> = ({durationInFrames, children}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [0, 12, durationInFrames - 12, durationInFrames], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const scale = interpolate(f, [0, durationInFrames], [1.02, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <div style={{position: 'absolute', inset: 0, opacity, transform: `scale(${scale})`}}>{children}</div>;
};
