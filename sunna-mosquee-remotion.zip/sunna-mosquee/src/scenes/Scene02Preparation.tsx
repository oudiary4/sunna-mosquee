import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Mosque} from '../components/Mosque';
import {Stickman} from '../components/Stickman';
import {AnimatedIcon} from '../components/AnimatedIcon';
import {AnimatedText} from '../components/AnimatedText';
import {SceneFade} from '../components/Transition';
import {C} from '../styles/colors';

// 00:07 -> 00:17 (300 frames). Narration : propreté, vêtements convenables, calme.
export const Scene02Preparation: React.FC = () => {
  const f = useCurrentFrame();
  const x = interpolate(f, [0, 200], [-140, 80], {extrapolateRight: 'clamp'});
  const arrowDash = interpolate(f, [60, 180], [200, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <SceneFade durationInFrames={300}>
      <AbsoluteFill>
        <Background />
        <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
          <Mosque x={0} y={200} scale={1.6} drawFrom={0} drawFrames={1} />
          {/* flèche animée */}
          <path d="M-320 -120 Q-200 -220 -80 -120" fill="none" stroke={C.gold} strokeWidth={6}
            strokeDasharray={200} strokeDashoffset={arrowDash} strokeLinecap="round" />
          {/* icône vêtements propres */}
          <AnimatedIcon kind="clothes" x={-300} y={-300} delay={40} size={2} />
          {/* icône calme */}
          <AnimatedIcon kind="quiet" x={300} y={-320} delay={100} size={2} />
          {/* icône chaussures près de l'entrée */}
          <AnimatedIcon kind="shoes" x={-120} y={240} delay={160} size={2} />
          <Stickman x={x} y={330} scale={1.6} walking={f < 200} />
        </svg>
        <div style={{position: 'absolute', top: 120, width: '100%'}}>
          <AnimatedText size={60} weight={800} color={C.darkGreen}>Avant d'entrer</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
