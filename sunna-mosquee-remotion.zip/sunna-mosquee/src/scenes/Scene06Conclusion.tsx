import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Mosque} from '../components/Mosque';
import {AnimatedIcon} from '../components/AnimatedIcon';
import {AnimatedText} from '../components/AnimatedText';
import {SceneFade} from '../components/Transition';
import {C} from '../styles/colors';

// 00:51 -> 01:00 (270 frames). Mosquée complète, icônes qui reviennent, halo doré.
export const Scene06Conclusion: React.FC = () => {
  const f = useCurrentFrame();
  const halo = interpolate(f, [0, 90], [0, 0.45], {extrapolateRight: 'clamp'});
  return (
    <SceneFade durationInFrames={270}>
      <AbsoluteFill>
        <Background />
        <AbsoluteFill style={{background: `radial-gradient(circle at 50% 30%, ${C.gold} 0%, transparent 55%)`, opacity: halo}} />
        <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
          <Mosque x={0} y={100} scale={1.5} drawFrom={0} drawFrames={1} />
          <AnimatedIcon kind="clothes" x={-380} y={-180} delay={30} />
          <AnimatedIcon kind="shoes" x={380} y={-180} delay={50} />
          <AnimatedIcon kind="quiet" x={-380} y={300} delay={70} />
          <AnimatedIcon kind="mat" x={380} y={300} delay={90} />
          <AnimatedIcon kind="heart" x={0} y={-420} delay={110} size={1.6} />
        </svg>
        <div style={{position: 'absolute', top: 1260, width: '100%'}}>
          <AnimatedText size={42} color={C.ink} delay={120}>La Sunna nous enseigne à respecter la mosquée,</AnimatedText>
          <AnimatedText size={56} weight={800} color={C.darkGreen} delay={180}>Respecter la mosquée, c'est honorer un lieu d'adoration.</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
