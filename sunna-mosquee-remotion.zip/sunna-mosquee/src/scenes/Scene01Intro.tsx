import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Mosque} from '../components/Mosque';
import {Stickman} from '../components/Stickman';
import {AnimatedText} from '../components/AnimatedText';
import {C} from '../styles/colors';
import {SceneFade} from '../components/Transition';

// 00:00 -> 00:07 (210 frames)
export const Scene01Intro: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = interpolate(f, [0, 210], [1, 1.08]);
  const walkX = interpolate(f, [0, 150], [-420, -140], {extrapolateRight: 'clamp'});
  return (
    <SceneFade durationInFrames={210}>
      <AbsoluteFill>
        <Background />
        <AbsoluteFill style={{transform: `scale(${zoom})`}}>
          <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
            <Mosque x={0} y={200} scale={1.6} drawFrom={0} drawFrames={70} />
            <Stickman x={walkX} y={300} scale={1.6} walking={f < 150} />
          </svg>
        </AbsoluteFill>
        <div style={{position: 'absolute', top: 260, width: '100%'}}>
          <AnimatedText size={84} weight={800} delay={40} color={C.darkGreen}>LES SUNNA DE LA MOSQUÉE</AnimatedText>
        </div>
        <div style={{position: 'absolute', top: 470, width: '100%'}}>
          <AnimatedText size={44} weight={300} delay={70} color={C.olive}>Les bonnes pratiques du musulman</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
