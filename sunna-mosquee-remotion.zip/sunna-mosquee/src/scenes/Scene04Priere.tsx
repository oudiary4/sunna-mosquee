import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Mosque} from '../components/Mosque';
import {Stickman} from '../components/Stickman';
import {AnimatedText} from '../components/AnimatedText';
import {SceneFade} from '../components/Transition';
import {C} from '../styles/colors';

// 00:27 -> 00:39 (360 frames). Travelling avant, tapis, deux rak'ahs symboliques.
export const Scene04Priere: React.FC = () => {
  const f = useCurrentFrame();
  const dolly = interpolate(f, [0, 200], [1, 1.25], {extrapolateRight: 'clamp'});
  const rug = interpolate(f, [20, 80], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const bowCycle = interpolate(f, [120, 360], [0, 2], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rakah = Math.min(2, Math.floor(bowCycle));
  return (
    <SceneFade durationInFrames={360}>
      <AbsoluteFill>
        <Background variant="beige" />
        <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
          <g transform={`scale(${dolly})`} style={{transformOrigin: '0 0'}}>
            {/* mihrab et colonnes */}
            <path d="M-120 -400 Q0 -560 120 -400 L120 -200 L-120 -200 Z" fill={C.gold} fillOpacity={0.6} stroke={C.darkGreen} strokeWidth={4} />
            {[-300, 300].map((cx) => <rect key={cx} x={cx - 14} y={-420} width={28} height={520} fill={C.beige} stroke={C.darkGreen} strokeWidth={4} />)}
            {/* tapis de prière */}
            <rect x={-240} y={80} width={480} height={200} rx={12} fill={C.olive} opacity={rug} stroke={C.darkGreen} strokeWidth={4} />
            <rect x={-200} y={110} width={400} height={140} rx={8} fill="none" stroke={C.gold} strokeWidth={3} opacity={rug} />
            {/* deux rak'ahs : le personnage s'incline puis se relève */}
            <Stickman x={-60} y={190} scale={1.4} bowing={rakah === 0 && f > 120} flip={false} />
          </g>
        </svg>
        <div style={{position: 'absolute', top: 1260, width: '100%'}}>
          <AnimatedText size={60} arabic color={C.darkGreen} delay={150}>تحية المسجد</AnimatedText>
          <AnimatedText size={44} color={C.olive} delay={190}>Tahiyyat al-Masjid</AnimatedText>
          <AnimatedText size={36} color={C.ink} delay={230}>Deux rak'ahs avant de s'asseoir</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
