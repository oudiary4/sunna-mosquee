import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {AnimatedText} from '../components/AnimatedText';
import {SceneFade} from '../components/Transition';
import {C} from '../styles/colors';

// 00:17 -> 00:27 (300 frames). Gros plan sur les pieds : le pied droit franchit le seuil.
// Caméra rapprochée, pieds dessinés, arc de mouvement naturel. Aucune représentation de personne au-delà des jambes.
const Foot: React.FC<{x: number; y: number; lift?: number; flip?: boolean}> = ({x, y, lift = 0, flip = false}) => (
  <g transform={`translate(${x} ${y - lift}) scale(${flip ? -1 : 1} 1)`}>
    {/* jambe (cheville vers le haut) */}
    <line x1={0} y1={-260} x2={0} y2={-40} stroke={C.ink} strokeWidth={22} strokeLinecap="round" />
    {/* robe pudique */}
    <path d="M-40 -300 L40 -300 L52 -200 L-52 -200 Z" fill={C.olive} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
    {/* pied : talon, voûte, orteils */}
    <path d="M-36 -40 Q-40 0 -10 8 L70 8 Q96 4 92 -20 Q88 -44 60 -44 L-10 -44 Z" fill={C.darkGreen} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
    <circle cx={78} cy={-14} r={8} fill={C.darkGreen} stroke={C.ink} strokeWidth={3} />
    <circle cx={60} cy={-4} r={6} fill={C.darkGreen} stroke={C.ink} strokeWidth={3} />
  </g>
);

export const Scene03Entree: React.FC = () => {
  const f = useCurrentFrame();
  // caméra : zoom progressif vers les pieds
  const cam = interpolate(f, [0, 300], [1.0, 1.3], {extrapolateRight: 'clamp'});
  // pied droit : avance de x=-160 à x=40 entre 40 et 170 frames, avec un arc (lift)
  const p = interpolate(f, [40, 170], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const footX = interpolate(p, [0, 1], [-160, 40]);
  const footLift = Math.sin(p * Math.PI) * 40;
  // pied gauche reste, légèrement décalé
  const leftX = -260;
  const bubble = interpolate(f, [170, 200], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const arrow = interpolate(f, [120, 170], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <SceneFade durationInFrames={300}>
      <AbsoluteFill>
        <Background />
        <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
          <g transform={`scale(${cam})`} style={{transformOrigin: '0 300px'}}>
            {/* seuil de la porte */}
            <rect x={-300} y={300} width={600} height={14} fill={C.darkGreen} />
            <rect x={-300} y={250} width={600} height={50} fill={C.beige} stroke={C.gold} strokeWidth={4} />
            {/* pied gauche (immobile) */}
            <Foot x={leftX} y={320} />
            {/* pied droit (en mouvement) */}
            <Foot x={footX} y={320} lift={footLift} />
            {/* flèche verte indiquant le mouvement */}
            <line x1={-120} y1={420} x2={60} y2={420} stroke={C.olive} strokeWidth={10} strokeLinecap="round"
              strokeDasharray={260} strokeDashoffset={260 * (1 - arrow)} />
          </g>
        </svg>
        {/* bulle d'invocation */}
        <div style={{position: 'absolute', top: 160, width: '100%', opacity: bubble}}>
          <AnimatedText size={72} arabic color={C.darkGreen} delay={170}>بِسْمِ اللَّهِ</AnimatedText>
          <AnimatedText size={46} arabic color={C.darkGreen} delay={190}>اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ</AnimatedText>
        </div>
        <div style={{position: 'absolute', top: 1180, width: '100%'}}>
          <AnimatedText size={38} color={C.olive} delay={210}>Allahumma iftah li abwaba rahmatik</AnimatedText>
          <AnimatedText size={38} color={C.ink} delay={240}>« Ô Allah, ouvre-moi les portes de Ta miséricorde. »</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
