import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {AnimatedIcon} from '../components/AnimatedIcon';
import {Stickman} from '../components/Stickman';
import {AnimatedText} from '../components/AnimatedText';
import {SceneFade} from '../components/Transition';
import {C} from '../styles/colors';

// 00:39 -> 00:51 (360 frames). Trois icônes reliées par des lignes animées.
export const Scene05Respect: React.FC = () => {
  const f = useCurrentFrame();
  const link = interpolate(f, [90, 200], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const dash = 400 * (1 - link);
  const nodes = [-300, 0, 300];
  return (
    <SceneFade durationInFrames={360}>
      <AbsoluteFill>
        <Background />
        <svg width={1080} height={1920} viewBox="-540 -960 1080 1920">
          {/* lignes animées */}
          <line x1={-300} y1={-100} x2={0} y2={-100} stroke={C.olive} strokeWidth={6} strokeDasharray={400} strokeDashoffset={dash} />
          <line x1={0} y1={-100} x2={300} y2={-100} stroke={C.olive} strokeWidth={6} strokeDasharray={400} strokeDashoffset={dash} />
          {/* 1. parler doucement (pictogramme : bulle) 2. tapis propre 3. laisser de l'espace */}
          <AnimatedIcon kind="quiet" x={nodes[0]} y={-100} delay={20} size={1.8} />
          <AnimatedIcon kind="mat" x={nodes[1]} y={-100} delay={60} size={1.8} />
          <AnimatedIcon kind="space" x={nodes[2]} y={-100} delay={100} size={1.8} />
          <Stickman x={-300} y={160} scale={1.4} walking={f > 120 && f < 260} />
          <Stickman x={300} y={160} scale={1.4} walking={f > 140 && f < 280} flip />
        </svg>
        <div style={{position: 'absolute', top: 240, width: '100%'}}>
          <AnimatedText size={60} weight={800} color={C.darkGreen}>Le respect de la mosquée</AnimatedText>
        </div>
        <div style={{position: 'absolute', top: 1240, width: '100%'}}>
          <AnimatedText size={38} color={C.ink} delay={220}>Propreté · discrétion · espace pour les autres</AnimatedText>
        </div>
      </AbsoluteFill>
    </SceneFade>
  );
};
