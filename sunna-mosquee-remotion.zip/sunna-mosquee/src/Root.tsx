import React from 'react';
import {Composition} from 'remotion';
import {SunnaMosquee} from './Composition';

// Format 9:16 (vertical) choisi : 1080 x 1920, 30 fps, 60 s.
export const RemotionRoot: React.FC = () => (
  <Composition
    id="SunnaMosquee"
    component={SunnaMosquee}
    durationInFrames={1800}
    fps={30}
    width={1080}
    height={1920}
  />
);
